<!-- start footer -->
<div class="page-footer">
	<div class="page-footer-inner"> 2017 &copy; Smart University Theme By
		<a href="mailto:redstartheme@gmail.com" target="_top" class="makerCss">Redstar Theme</a>
	</div>
	<div class="scroll-to-top">
		<i class="icon-arrow-up"></i>
	</div>
</div>
<!-- end footer -->
</div>
<!-- start js include path -->
<script src="<?= base_url()?>assets/dashboard/plugins/jquery/jquery.min.js"></script>
<script src="<?= base_url()?>assets/dashboard/plugins/popper/popper.js"></script>
<script src=".<?= base_url()?>assets/dashboard/plugins/jquery-blockui/jquery.blockui.min.js"></script>
<script src="<?= base_url()?>assets/dashboard/plugins/jquery-slimscroll/jquery.slimscroll.js"></script>
<!-- bootstrap -->
<script src="<?= base_url()?>assets/dashboard/plugins/bootstrap/js/bootstrap.min.js"></script>
<script src="<?= base_url()?>assets/dashboard/plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>
<script src="<?= base_url()?>assets/dashboard/plugins/sparkline/jquery.sparkline.js"></script>
<script src="<?= base_url()?>assets/dashboard/js/pages/sparkline/sparkline-data.js"></script>

<!-- data tables -->
<script src="<?= base_url()?>assets/dashboard/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?= base_url()?>assets/dashboard/plugins/datatables/plugins/bootstrap/dataTables.bootstrap4.min.js"></script>
<script src="<?= base_url()?>assets/dashboard/js/pages/table/table_data.js"></script>

<!-- Common js-->
<script src="<?= base_url()?>assets/dashboard/js/app.js"></script>
<script src="<?= base_url()?>assets/dashboard/js/layout.js"></script>
<script src="<?= base_url()?>assets/dashboard/js/theme-color.js"></script>
<!-- material -->
<script src="<?= base_url()?>assets/dashboard/plugins/material/material.min.js"></script>
<!--apex chart-->
<script src="<?= base_url()?>assets/dashboard/plugins/apexcharts/apexcharts.min.js"></script>
<script src="<?= base_url()?>assets/dashboard/js/pages/chart/chartjs/home-data.js"></script>
<!-- summernote -->
<script src="<?= base_url()?>assets/dashboard/plugins/summernote/summernote.js"></script>
<script src="<?= base_url()?>assets/dashboard/js/pages/summernote/summernote-data.js"></script>
<!-- end js include path -->
</body>
<!-- Mirrored from www.einfosoft.com/templates/admin/smart/source/light/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 25 Jan 2022 07:10:50 GMT -->
</html>
